import numpy as np
import matplotlib.pyplot as plt
import uncertainties as unc
import uncertainties.unumpy as unp
from uncertainties import ufloat
from scipy.optimize import curve_fit
import scipy.constants as const
import sympy
import os
from uncertainties.unumpy import (nominal_values as noms, std_devs as stds)
from scipy.signal import find_peaks

if os.path.exists("build") == False:
    os.mkdir("build")

if os.path.exists("build/plots") == False:
    os.mkdir("build/plots")



########MESSWERTE#######

###Justage###
detectorscan, detectorscan_I = np.genfromtxt("python/data/detektorscan.UXD",skip_header= 57, unpack = True)
z1, z1_I = np.genfromtxt("python/data/z1.UXD",skip_header= 57, unpack = True)
x1_2theta, x1_I = np.genfromtxt("python/data/x1.UXD",skip_header= 57, unpack = True)
just_rock1_2theta, just_rock1_I = np.genfromtxt("python/data/just_rock1.UXD",skip_header= 57, unpack = True)
z2_2theta, z2_I = np.genfromtxt("python/data/z2.UXD",skip_header= 57, unpack = True)
just_rock2_2theta, just_rock2_I = np.genfromtxt("python/data/just_rock2.UXD",skip_header= 57, unpack = True)
z3_2theta, z3_I = np.genfromtxt("python/data/z3.UXD",skip_header= 57, unpack = True)



###Messwerte###



diffus_2theta, diffus_I = np.genfromtxt("python/data/diffus.UXD",skip_header= 56, unpack = True)
refl_2theta, refl_I = np.genfromtxt("python/data/reflektivitat.UXD",skip_header= 57, unpack = True)
just_rock3_2theta, just_rock3_I = np.genfromtxt("python/data/just_rock_03.UXD",skip_header= 57, unpack = True)
test_2theta, test_I = np.genfromtxt("python/data/test.UXD",skip_header= 57, unpack = True)

###Theoriewerte###

dicke = 20 # in mm
lam = 1.54e-10      #K-alpha Linie
n = 1 - 7.6e-6 + 1.54e-8j*141/(4*np.pi)
k = 2*np.pi / lam
print("\t\t k = ", k)

#Silizium

sil_rho = 20 * 10**(-6) # per metre**2
sil_del = 7.6 * 10**(-6)
sil_mu = 8600 #per metre
sil_alpha = 0.174 # degree

#Polyester

poly_rho = 9.5 * 10**(-6) # per metre**2
poly_del = 3.5 * 10**(-6)
poly_mu = 400 #per metre
poly_alpha = 0.153 # degree

#####RECHNUNGEN#######














###Funktionen###


def geometrie_corr(I, alpha, alpha_g, beam_width,D):
    I_corr = np.zeros(np.size(I))
    G = 1
    for i in range(np.size(I)):
        #print(alpha[i],"\t", alpha_g)
        if( np.abs(alpha_g) > alpha[i]):
            G = D * np.sin(alpha[i] * np.pi/180) / beam_width
        else:
            G = 1
        #print(G)
        I_corr[i] = I[i] / G
        I_corr[0] = I[0]
    return I_corr


def parrat_neu(a_i, delta2, delta3, sigma2, sigma3, z2, beta2, beta3):
    n2 = 1 - delta2 + 1j*beta2
    n3 = 1 - delta3 + 1j*beta3

    a_i = a_i * np.pi/180 #conversion to rad


    kz1 = k * np.sqrt(n1**2-np.cos(a_i)**2)
    kz2 = k * np.sqrt(n2**2-np.cos(a_i)**2)
    kz3 = k * np.sqrt(n3**2-np.cos(a_i)**2)


    r12 = (kz1 - kz2) / (kz1 + kz2) * np.exp(-2 * sigma2**2 * kz1 * kz2 )
    r23 = (kz2 - kz3) / (kz2 + kz3) * np.exp(-2 * sigma3**2 * kz2 * kz3 )


    x2 = np.exp(-2j * kz2 * z2) * r23
    x1 = (r12 + x2) / (1 + r12 * x2)

    R_parr = np.abs(x1)**2

    return R_parr


loc_1 = 23
loc_2 = 30

beam_width = z1[loc_2] - z1[loc_1]

gauss_max = 838646.2462

alpha_g1 = just_rock1_2theta[6]
alpha_g2 = just_rock1_2theta[-4]
alpha_ges = 1/2 *(alpha_g1 - alpha_g2)

### Geometriefaktor###
print("\n\n---Geometriefaktor---")

print(refl_2theta[1] - refl_2theta[0])
print(diffus_2theta[1] - diffus_2theta[0])

normierung_zeit = (refl_2theta[1] - refl_2theta[0]) * 10**3


refl_I_corr = refl_I / (normierung_zeit)
diffus_I_corr = diffus_I /(normierung_zeit)



refl_I_corr = geometrie_corr(refl_I_corr, refl_2theta, alpha_ges, beam_width, dicke)
diffus_I_corr = geometrie_corr(diffus_I_corr, diffus_2theta, alpha_ges, beam_width, dicke)


corr_data = refl_I_corr - diffus_I_corr




###Parrat###
print(f"\n\n---Paratt---")



########################## 2 entspricht poly und 3 sil

n1 = 1 #Luft
delta2 = 10*10**(-7)
delta3 = 8.15*10**(-6)
sigma2 = 9*10**(-10) # m
sigma3 = 7.8*10**(-10) # m 
z2 = 8.8*10**(-8) # m   
beta2 = 3 * 10**(-10)
beta3 = delta3/50 


x = np.linspace(refl_2theta[0], refl_2theta[-1],10000)
plt.figure()
plt.plot(x, parrat_neu(x, delta2, delta3, sigma2, sigma3, z2, beta2, beta3),color ="teal", label = "Paratt-Fit (händisch)")
#plt.plot(x, parrat_neu(x, delta2plus, delta3plus, sigma1plus, sigma2plus, z2plus, beta2plus, beta3plus), alpha = 0.5, label = "Paratt-Fit (+)")
#plt.plot(x, parrat_neu(x, delta2minus, delta3minus, sigma1minus, sigma2minus, z2minus, beta2minus, beta3minus), alpha = 0.5, label = "Paratt-Fit (-)")
plt.plot(refl_2theta, corr_data/ gauss_max, color = "orange", label="korrigierte Daten")
plt.yscale('log')
plt.ylabel(r"Reflektivität")
plt.xlabel(r"$\alpha_{i}$ $/$ Grad")
plt.tight_layout()
plt.legend()
plt.savefig("build/plots/paratt.pdf")

